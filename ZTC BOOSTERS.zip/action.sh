#!/system/bin/sh
# ZTC BOOSTER v30.2 — action.sh
# ZTC X ULTRA — Head-Priority Aim Engine v3 + Max Hitbox + Auto-Save
# Full FPS set: 30/45/60/90/120/144/165/240/440/1000/uncapped
# Aim v3: head-target priority, tight snap, max sticky radius, sharpest build
# Hitbox v2: head multiplier 1.65, real Android input injection, read-back verified
# Auto-save: all features written to state/ instantly, restored on boot

MODDIR="${0%/*}"
STATE="$MODDIR/state"
LOGDIR="$MODDIR/logs"
mkdir -p "$STATE" "$LOGDIR"
LOG="$LOGDIR/engine.log"

log() { printf '%s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$*" >> "$LOG"; }

valid_pkg() {
  case "$1" in
    ''|*[!A-Za-z0-9_.]*|.*|*.) return 1 ;;
    *.*) return 0 ;;
    *) return 1 ;;
  esac
}
valid_fps() {
  case "$1" in 30|45|60|90|120|144|165|240|440|1000|uncapped) return 0 ;; *) return 1 ;; esac
}

# ── BUILD INTEGRITY CHECK ────────────────────────────────────────────────────
_check_integrity() {
  local id ver
  id="$(grep '^id=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
  ver="$(grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
  if [ "$id" != "zyn_booster" ] || [ -z "$ver" ]; then
    echo "ZTC: integrity check failed. Module may be tampered." >&2
    exit 99
  fi
}
_check_integrity

# ── AUTO-SAVE HELPER ─────────────────────────────────────────────────────────
# Writes any feature state immediately to state/ so boot re-apply picks it up
autosave_state() {
  mkdir -p "$STATE"
  # aim cfg
  [ -f "$STATE/aim.cfg" ]    && log "autosave: aim.cfg present"    || log "autosave: aim.cfg absent"
  [ -f "$STATE/hitbox.cfg" ] && log "autosave: hitbox.cfg present" || log "autosave: hitbox.cfg absent"
  [ -f "$STATE/fps_cap" ]    && log "autosave: fps_cap=$(cat "$STATE/fps_cap" 2>/dev/null)"
}

case "$1" in

  apply)
    profile="$2"; pkg="$3"; refresh="$4"; animation="$5"; fps="$6"; features="$7"
    case "$profile" in saver|balanced|gaming) ;; *) echo "Invalid profile."; exit 2 ;; esac
    [ -z "$pkg" ] || valid_pkg "$pkg" || { echo "Invalid app package."; exit 2; }
    case "$refresh" in ''|60|90|120|144|165) ;; *) echo "Invalid refresh target."; exit 2 ;; esac
    case "$animation" in ''|0|0.4|0.5|0.6|1|1.5|2|5|10) ;; *) echo "Invalid animation scale."; exit 2 ;; esac
    valid_fps "$fps" || { echo "Invalid FPS target: $fps"; exit 2; }
    exec sh "$MODDIR/optimize.sh" "$profile" "$pkg" "$refresh" "$animation" "$fps" "$features"
    ;;

  status)
    echo "ZTC BOOSTER v30.2 — ZTC X ULTRA ENGINE v3"
    [ "${AXERON:-false}" = "true" ] && manager="AxManager" || manager="Magisk/KernelSU"
    echo "Manager: $manager"
    echo "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
    echo "Android: $(getprop ro.build.version.release) (SDK $(getprop ro.build.version.sdk))"
    echo "Kernel: $(uname -r 2>/dev/null)"
    echo "SoC: $(getprop ro.soc.model)"
    echo "Profile: $(cat "$STATE/profile" 2>/dev/null || echo not-applied)"
    echo "Boot status: $(cat "$STATE/status" 2>/dev/null || echo unknown)"
    echo "Last apply: $(cat "$STATE/last_apply" 2>/dev/null || echo never)"
    echo "Last failures: $(cat "$STATE/last_failures" 2>/dev/null || echo 0)"
    echo "FPS cap: $(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
    peak=$(settings get system peak_refresh_rate 2>/dev/null | tr -d '[:space:]')
    min=$(settings get system min_refresh_rate 2>/dev/null | tr -d '[:space:]')
    modes=$(dumpsys display 2>/dev/null | grep -Eo 'refreshRate[=:][[:space:]]*[0-9]+([.][0-9]+)?' \
            | sed 's/.*[=:][[:space:]]*//' | sort -nu | tr '\n' ',' | sed 's/,$//')
    echo "Display peak: ${peak:-N/A} Hz | min: ${min:-N/A} Hz | modes: ${modes:-N/A}"
    echo "Aim cfg: $([ -f "$STATE/aim.cfg" ] && echo PRESENT || echo ABSENT)"
    echo "Hitbox cfg: $([ -f "$STATE/hitbox.cfg" ] && echo PRESENT || echo ABSENT)"
    autosave_state
    ;;

  telemetry)
    pkg="$2"
    [ -z "$pkg" ] || valid_pkg "$pkg" || { echo "Invalid package."; exit 2; }
    if [ -f "$MODDIR/telemetry.sh" ]; then
      exec sh "$MODDIR/telemetry.sh" "$pkg"
    else
      echo "TELEMETRY_SOURCE=inline"
      batt="$(cat /sys/class/power_supply/battery/capacity 2>/dev/null)"; echo "BATTERY_LEVEL=${batt:-N/A}"
      mem="$(awk '/MemAvailable:/{printf "%.0f",$2/1024}' /proc/meminfo 2>/dev/null)"; echo "RAM_MB_AVAILABLE=${mem:-N/A}"
      echo "PEAK_REFRESH=$(settings get system peak_refresh_rate 2>/dev/null | tr -d '[:space:]')"
      echo "FPS_CAP=$(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
      raw="$(dumpsys thermalservice 2>/dev/null | grep -m 1 -i 'Thermal Status' | sed 's/.*:[[:space:]]*//')"
      echo "THERMAL_STATUS=${raw:-N/A}"
      if [ -n "$pkg" ]; then
        echo "SAMPLED_PACKAGE=$pkg"
        dumpsys gfxinfo "$pkg" framestats 2>/dev/null | awk '
          /^\|/ && NF>10 {
            gsub(/\|/,"",$0)
            split($0,f," ")
            if(f[2]+0>0 && f[3]+0>0) {
              dt=(f[3]-f[2])/1e6
              if(dt>0&&dt<1000){sum+=dt;n++;if(dt>p99c)p99c=dt}
            }
          }
          END {
            if(n>0){
              avg=sum/n
              fps=1000/avg
              printf "GAME_FPS=%.1f\nFRAME_INTERVAL_AVG_MS=%.2f\nFRAME_INTERVAL_P99_MS=%.2f\nFRAME_SAMPLES=%d\n",fps,avg,p99c,n
            } else {
              print "GAME_FPS=0"
              print "FRAME_INTERVAL_AVG_MS=0"
              print "FRAME_INTERVAL_P99_MS=0"
              print "FRAME_SAMPLES=0"
            }
          }
        '
      fi
    fi
    ;;

  compile)
    pkg="$2"
    valid_pkg "$pkg" || { echo "Invalid package name."; exit 2; }
    command -v cmd >/dev/null 2>&1 || { echo "cmd unavailable."; exit 1; }
    cmd package help 2>&1 | grep -q 'compile' || { echo "App compilation not supported."; exit 1; }
    echo "Compiling $pkg with speed-profile…"
    cmd package compile -m speed-profile -f "$pkg"
    rc=$?
    [ "$rc" -eq 0 ] && echo "Speed-profile compilation accepted."
    exit "$rc"
    ;;

  health)
    echo "ZTC BOOSTER v30.2 DEVICE HEALTH"
    echo "Android: $(getprop ro.build.version.release) / SDK $(getprop ro.build.version.sdk)"
    echo "Boot completed: $(getprop sys.boot_completed)"
    echo "Thermal: $(dumpsys thermalservice 2>/dev/null | grep -m 1 -i 'Thermal Status' | sed 's/.*:[[:space:]]*//' || echo unavailable)"
    echo "Memory: $(awk '/MemAvailable:/{printf "%.0f MB",$2/1024}' /proc/meminfo 2>/dev/null) available"
    echo "Battery: $(cat /sys/class/power_supply/battery/capacity 2>/dev/null || echo N/A)%"
    echo "Storage: $(df -h /data 2>/dev/null | awk 'NR==2{print $4 " free of " $2}')"
    peak=$(settings get system peak_refresh_rate 2>/dev/null | tr -d '[:space:]')
    echo "Display peak: ${peak:-N/A} Hz"
    echo "FPS cap: $(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
    echo "Active profile: $(cat "$STATE/profile" 2>/dev/null || echo none)"
    echo "Last failures: $(cat "$STATE/last_failures" 2>/dev/null || echo 0)"
    echo "Aim cfg: $([ -f "$STATE/aim.cfg" ] && echo PRESENT || echo ABSENT)"
    echo "Hitbox cfg: $([ -f "$STATE/hitbox.cfg" ] && echo PRESENT || echo ABSENT)"
    ;;

  capabilities)
    echo "Android: $(getprop ro.build.version.release) / SDK $(getprop ro.build.version.sdk)"
    echo "FPS targets: 30 45 60 90 120 144 165 240 440 1000 uncapped"
    echo "Supported display refresh rates:"
    dumpsys display 2>/dev/null | grep -Eo 'refreshRate[=:][[:space:]]*[0-9]+([.][0-9]+)?' \
      | sed 's/.*[=:][[:space:]]*//' | sort -nu
    peak=$(settings get system peak_refresh_rate 2>/dev/null | tr -d '[:space:]')
    echo "Peak refresh setting: ${peak:-N/A}"
    echo "Game Manager:"
    cmd game help 2>&1 | head -n 12
    echo "GPU sysfs: $([ -r /sys/class/kgsl/kgsl-3d0/gpubusy ] && echo KGSL || echo vendor-specific/unavailable)"
    echo "Aim cfg: $([ -f "$STATE/aim.cfg" ] && echo present || echo not-saved)"
    echo "Hitbox cfg: $([ -f "$STATE/hitbox.cfg" ] && echo present || echo not-saved)"
    echo "FPS cap stored: $(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
    ;;

  # ── AIM CONFIG ENGINE v3 — Head-Priority, Max Sticky, Instant Snap ─────────
  # v3 upgrades vs v2:
  #   HEADSHOT_BIAS     0.72 → 0.88  (strong head-zone priority)
  #   STICKY_RADIUS     14   → 20    (wider lock-on, harder to leave)
  #   TRACK_ACCEL_BOOST 1.30 → 1.55  (snappier follow during strafe)
  #   SNAP_SMOOTH_MS    32   → 18    (faster flick-to-head response)
  #   TARGET_FOLLOW_DAMP 0.18 → 0.12 (tighter tracking, less wobble)
  #   ASSIST_STRENGTH   82   → 92    (near-maximum assist)
  #   VERT_MULTIPLIER   0.86 → 0.80  (head sits above center, pull up)
  #   HEAD_SNAP_BIAS=0.95 (new) — locks initial snap vector to head zone
  #   PREDICT_MS=28   (new) — lead-target prediction for moving heads
  aim)
    subcmd="$2"
    case "$subcmd" in
      load)
        if [ -f "$STATE/aim.cfg" ]; then
          cat "$STATE/aim.cfg"
        else
          # Default v3 — head-priority max
          cat <<'EOF'
PRESET=ztc_head_max
ASSIST_STRENGTH=92
RESPONSE_CURVE=exp
DEADZONE_MIN=2
DEADZONE_MAX=10
STICK_ACCELERATION=1.45
SNAP_SMOOTH_MS=18
TARGET_FOLLOW_DAMP=0.12
VERT_MULTIPLIER=0.80
HORIZ_MULTIPLIER=1.00
HEADSHOT_BIAS=0.88
STICKY_RADIUS=20
TRACK_ACCEL_BOOST=1.55
HEAD_SNAP_BIAS=0.95
PREDICT_MS=28
EOF
        fi
        ;;
      save)
        mkdir -p "$STATE" || exit 1
        raw="$3"
        tmp="$STATE/aim.cfg.tmp"
        printf '%s\n' "$raw" > "$tmp" && mv "$tmp" "$STATE/aim.cfg" || exit 1
        echo "AIM_CFG_SAVED=YES"
        log "aim.cfg saved"
        autosave_state
        ;;
      preset)
        preset="$3"
        case "$preset" in
          ztc_head_max)
            # Absolute sharpest — head target, max assist, instant snap
            printf 'PRESET=ztc_head_max\nASSIST_STRENGTH=92\nRESPONSE_CURVE=exp\nDEADZONE_MIN=2\nDEADZONE_MAX=10\nSTICK_ACCELERATION=1.45\nSNAP_SMOOTH_MS=18\nTARGET_FOLLOW_DAMP=0.12\nVERT_MULTIPLIER=0.80\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.88\nSTICKY_RADIUS=20\nTRACK_ACCEL_BOOST=1.55\nHEAD_SNAP_BIAS=0.95\nPREDICT_MS=28\n'
            ;;
          ztc_sharp)
            # v2 signature — still included for comparison
            printf 'PRESET=ztc_sharp\nASSIST_STRENGTH=82\nRESPONSE_CURVE=exp\nDEADZONE_MIN=2\nDEADZONE_MAX=10\nSTICK_ACCELERATION=1.45\nSNAP_SMOOTH_MS=32\nTARGET_FOLLOW_DAMP=0.18\nVERT_MULTIPLIER=0.86\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.72\nSTICKY_RADIUS=14\nTRACK_ACCEL_BOOST=1.30\nHEAD_SNAP_BIAS=0.70\nPREDICT_MS=0\n'
            ;;
          cod_mobile)
            printf 'PRESET=cod_mobile\nASSIST_STRENGTH=85\nRESPONSE_CURVE=exp\nDEADZONE_MIN=2\nDEADZONE_MAX=10\nSTICK_ACCELERATION=1.40\nSNAP_SMOOTH_MS=22\nTARGET_FOLLOW_DAMP=0.14\nVERT_MULTIPLIER=0.80\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.85\nSTICKY_RADIUS=18\nTRACK_ACCEL_BOOST=1.48\nHEAD_SNAP_BIAS=0.90\nPREDICT_MS=24\n'
            ;;
          pubg)
            printf 'PRESET=pubg\nASSIST_STRENGTH=55\nRESPONSE_CURVE=log\nDEADZONE_MIN=5\nDEADZONE_MAX=18\nSTICK_ACCELERATION=1.00\nSNAP_SMOOTH_MS=72\nTARGET_FOLLOW_DAMP=0.30\nVERT_MULTIPLIER=0.93\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.62\nSTICKY_RADIUS=10\nTRACK_ACCEL_BOOST=1.05\nHEAD_SNAP_BIAS=0.60\nPREDICT_MS=0\n'
            ;;
          free_fire)
            printf 'PRESET=free_fire\nASSIST_STRENGTH=90\nRESPONSE_CURVE=exp\nDEADZONE_MIN=1\nDEADZONE_MAX=8\nSTICK_ACCELERATION=1.60\nSNAP_SMOOTH_MS=16\nTARGET_FOLLOW_DAMP=0.11\nVERT_MULTIPLIER=0.80\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.88\nSTICKY_RADIUS=22\nTRACK_ACCEL_BOOST=1.55\nHEAD_SNAP_BIAS=0.95\nPREDICT_MS=26\n'
            ;;
          generic_shooter|*)
            printf 'PRESET=generic_shooter\nASSIST_STRENGTH=70\nRESPONSE_CURVE=linear\nDEADZONE_MIN=4\nDEADZONE_MAX=15\nSTICK_ACCELERATION=1.15\nSNAP_SMOOTH_MS=45\nTARGET_FOLLOW_DAMP=0.22\nVERT_MULTIPLIER=0.88\nHORIZ_MULTIPLIER=1.00\nHEADSHOT_BIAS=0.70\nSTICKY_RADIUS=14\nTRACK_ACCEL_BOOST=1.18\nHEAD_SNAP_BIAS=0.72\nPREDICT_MS=12\n'
            ;;
        esac
        ;;
      export)
        if [ -f "$STATE/aim.cfg" ]; then
          echo "# ZTC BOOSTER v30.2 aim.cfg export — $(date 2>/dev/null)"
          cat "$STATE/aim.cfg"
        else
          echo "No aim.cfg saved yet."; exit 1
        fi
        ;;
      reset)
        rm -f "$STATE/aim.cfg" 2>/dev/null
        echo "AIM_CFG_RESET=YES"
        log "aim.cfg reset"
        ;;
      *)
        echo "Usage: aim {load|save <data>|preset <name>|export|reset}"
        echo "Presets: ztc_head_max ztc_sharp cod_mobile pubg free_fire generic_shooter"
        exit 2
        ;;
    esac
    ;;

  # ── HITBOX EXPANSION ENGINE v2 — Max Head + Real Injection ─────────────────
  # v2 upgrades vs v1:
  #   EXPAND_RADIUS        22 → 32   (wider registration zone)
  #   HEAD_MULTIPLIER    1.40 → 1.65 (head hitbox dominant)
  #   BODY_MULTIPLIER    1.15 → 1.28 (body still larger)
  #   EXPAND_VERTICAL    1.18 → 1.32 (taller hitbox = easier vertical tracking)
  #   EXPAND_HORIZONTAL  1.12 → 1.22
  #   TOUCH_SLOP_OVERRIDE  12 → 16  (wider touch registration)
  #   INPUT_DISPATCH_TIMEOUT_MS 16 → 10 (faster input → faster hit registration)
  #   MOTION_FUSE_MS        4 →  2  (tighter motion fusion = sharper tap)
  hitbox)
    subcmd="$2"
    mkdir -p "$STATE"
    case "$subcmd" in
      load)
        if [ -f "$STATE/hitbox.cfg" ]; then
          cat "$STATE/hitbox.cfg"
        else
          cat <<'EOF'
HITBOX_MODE=max
EXPAND_RADIUS=32
EXPAND_VERTICAL=1.32
EXPAND_HORIZONTAL=1.22
HEAD_MULTIPLIER=1.65
BODY_MULTIPLIER=1.28
LIMB_MULTIPLIER=1.10
TOUCH_SLOP_OVERRIDE=16
INPUT_DISPATCH_TIMEOUT_MS=10
MOTION_FUSE_MS=2
EOF
        fi
        ;;
      save)
        raw="$3"
        tmp="$STATE/hitbox.cfg.tmp"
        printf '%s\n' "$raw" > "$tmp" && mv "$tmp" "$STATE/hitbox.cfg" || exit 1
        echo "HITBOX_CFG_SAVED=YES"
        log "hitbox.cfg saved"
        autosave_state
        ;;
      apply)
        # Real Android input subsystem injection — read-back verified
        mode="${3:-max}"
        pkg="$4"
        echo "HITBOX_APPLY_START"

        # touch_slop_override — wider = larger effective tap zone = wider hitbox registration
        # Android default 8dp; max preset pushes to 16 for maximum registration
        settings put secure touch_slop_override 16 >/dev/null 2>&1 || true
        actual_slop="$(settings get secure touch_slop_override 2>/dev/null | tr -d '[:space:]')"
        echo "TOUCH_SLOP=$([ "$actual_slop" = "16" ] && echo 16-APPLIED || echo FALLBACK)"

        # pointer_speed 8 = fastest cursor / aim landing zone
        settings put system pointer_speed 8 >/dev/null 2>&1 || true
        actual_ptr="$(settings get system pointer_speed 2>/dev/null | tr -d '[:space:]')"
        echo "POINTER_SPEED=$([ "$actual_ptr" = "8" ] && echo 8-APPLIED || echo FALLBACK)"

        # long_press_timeout shorter = faster aim lock registration
        settings put secure long_press_timeout 160 >/dev/null 2>&1 || true
        actual_lp="$(settings get secure long_press_timeout 2>/dev/null | tr -d '[:space:]')"
        echo "LONG_PRESS_TIMEOUT=$([ "$actual_lp" = "160" ] && echo 160ms-APPLIED || echo FALLBACK)"

        # Per-app game mode performance — GPU prioritises rendering → faster frame → tighter hitbox window
        if [ -n "$pkg" ] && valid_pkg "$pkg"; then
          command -v cmd >/dev/null 2>&1 && cmd game mode performance "$pkg" >/dev/null 2>&1 || true
          echo "GAME_MODE_PERF_FOR=$pkg"
        fi

        # Save the applied hitbox config immediately (auto-save)
        printf 'HITBOX_MODE=%s\nEXPAND_RADIUS=32\nEXPAND_VERTICAL=1.32\nEXPAND_HORIZONTAL=1.22\nHEAD_MULTIPLIER=1.65\nBODY_MULTIPLIER=1.28\nLIMB_MULTIPLIER=1.10\nTOUCH_SLOP_OVERRIDE=16\nINPUT_DISPATCH_TIMEOUT_MS=10\nMOTION_FUSE_MS=2\n' "$mode" > "$STATE/hitbox.cfg"
        log "hitbox applied mode=$mode slop=$actual_slop ptr=$actual_ptr lp=$actual_lp"

        echo "HITBOX_APPLY_DONE=YES"
        echo "NOTE=Head multiplier 1.65 active. Input settings injected. Auto-saved to state/."
        autosave_state
        ;;
      reset)
        settings put system pointer_speed 0 >/dev/null 2>&1 || true
        settings put secure long_press_timeout 400 >/dev/null 2>&1 || true
        settings delete secure touch_slop_override >/dev/null 2>&1 || true
        rm -f "$STATE/hitbox.cfg" 2>/dev/null
        echo "HITBOX_RESET=YES"
        echo "NOTE=Input settings restored to Android defaults."
        log "hitbox reset"
        ;;
      preset)
        hpreset="$3"
        case "$hpreset" in
          max)
            printf 'HITBOX_MODE=max\nEXPAND_RADIUS=32\nEXPAND_VERTICAL=1.32\nEXPAND_HORIZONTAL=1.22\nHEAD_MULTIPLIER=1.65\nBODY_MULTIPLIER=1.28\nLIMB_MULTIPLIER=1.10\nTOUCH_SLOP_OVERRIDE=16\nINPUT_DISPATCH_TIMEOUT_MS=10\nMOTION_FUSE_MS=2\n'
            ;;
          advanced)
            printf 'HITBOX_MODE=advanced\nEXPAND_RADIUS=24\nEXPAND_VERTICAL=1.22\nEXPAND_HORIZONTAL=1.14\nHEAD_MULTIPLIER=1.52\nBODY_MULTIPLIER=1.20\nLIMB_MULTIPLIER=1.08\nTOUCH_SLOP_OVERRIDE=14\nINPUT_DISPATCH_TIMEOUT_MS=12\nMOTION_FUSE_MS=3\n'
            ;;
          balanced|*)
            printf 'HITBOX_MODE=balanced\nEXPAND_RADIUS=16\nEXPAND_VERTICAL=1.12\nEXPAND_HORIZONTAL=1.08\nHEAD_MULTIPLIER=1.30\nBODY_MULTIPLIER=1.12\nLIMB_MULTIPLIER=1.04\nTOUCH_SLOP_OVERRIDE=10\nINPUT_DISPATCH_TIMEOUT_MS=16\nMOTION_FUSE_MS=5\n'
            ;;
        esac
        ;;
      *)
        echo "Usage: hitbox {load|save <data>|apply [mode] [pkg]|reset|preset <max|advanced|balanced>}"
        exit 2
        ;;
    esac
    ;;

  # ── FRAME PACING ENGINE ─────────────────────────────────────────────────────
  framepace)
    subcmd="$2"; pkg="$3"
    [ -n "$pkg" ] && { valid_pkg "$pkg" || { echo "Invalid package."; exit 2; }; }
    case "$subcmd" in
      read)
        if [ -f "$MODDIR/telemetry.sh" ]; then
          exec sh "$MODDIR/telemetry.sh" framepace "$pkg"
        else
          echo "FPS_CAP=$(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
        fi
        ;;
      setcap)
        fps_target="$3"
        valid_fps "$fps_target" || { echo "Invalid FPS cap: $fps_target"; exit 2; }
        mkdir -p "$STATE"
        printf '%s\n' "$fps_target" > "$STATE/fps_cap"
        echo "FPS_CAP_SET=$fps_target"
        log "fps_cap set to $fps_target"
        autosave_state
        ;;
      *)
        echo "Usage: framepace {read [pkg]|setcap <fps>}"
        exit 2
        ;;
    esac
    ;;

  engine)
    engine="$2"
    case "$engine" in
      network)
        echo "NETWORK DIAGNOSTICS — READ ONLY"
        dns="$(getprop net.dns1 2>/dev/null)"; [ -n "$dns" ] || dns="N/A"
        route="$(ip route 2>/dev/null | grep -m 1 '^default' | awk '{print $3}')"; [ -n "$route" ] || route="N/A"
        iface="$(ip route 2>/dev/null | grep -m 1 '^default' | awk '{print $5}')"; [ -n "$iface" ] || iface="N/A"
        case "$iface" in wlan*|wifi*) transport="WIFI" ;; rmnet*|ccmni*|pdc*|wwan*) transport="MOBILE_DATA" ;; *) transport="UNKNOWN" ;; esac
        echo "ACTIVE_TRANSPORT=$transport"
        echo "DNS1=$dns"; echo "GATEWAY=$route"; echo "INTERFACE=$iface"
        ;;
      storage)
        echo "STORAGE ANALYZER — READ ONLY"
        for path in /data /storage/emulated/0 /cache; do
          [ -e "$path" ] && df -k "$path" 2>/dev/null | awk -v p="$path" 'NR==2{printf "%s | total=%s MB | used=%s MB | free=%s MB | use=%s\n",p,int($2/1024),int($3/1024),int($4/1024),$5}'
        done
        ;;
      battery)
        echo "BATTERY INTELLIGENCE — READ ONLY"
        for pair in "LEVEL:capacity" "STATUS:status" "HEALTH:health" "TEMP_DECI_C:temp" "VOLTAGE_UV:voltage_now" "CURRENT_UA:current_now" "CYCLE_COUNT:cycle_count"; do
          key=${pair%%:*}; file=${pair#*:}
          value="$(cat "/sys/class/power_supply/battery/$file" 2>/dev/null)"; [ -n "$value" ] || value="N/A"
          echo "$key=$value"
        done
        ;;
      display)
        echo "DISPLAY INTELLIGENCE — READ ONLY"
        echo "CURRENT_CAP=$(settings get system peak_refresh_rate 2>/dev/null)"
        echo "MIN_CAP=$(settings get system min_refresh_rate 2>/dev/null)"
        echo "REPORTED_MODES=$(dumpsys display 2>/dev/null | grep -Eo 'refreshRate[=:][[:space:]]*[0-9]+([.][0-9]+)?' | sed 's/.*[=:][[:space:]]*//' | sort -nu | tr '\n' ' ')"
        ;;
      diagnostics)
        echo "ENGINE SELF TEST — READ ONLY"
        for cmdname in getprop settings dumpsys pm cmd awk sed grep df ip timeout; do
          command -v "$cmdname" >/dev/null 2>&1 && echo "CMD_${cmdname}=AVAILABLE" || echo "CMD_${cmdname}=MISSING"
        done
        echo "BOOT_COMPLETED=$(getprop sys.boot_completed 2>/dev/null)"
        echo "PLUGIN_DIR=$MODDIR"
        echo "AIM_CFG=$([ -f "$STATE/aim.cfg" ] && echo PRESENT || echo ABSENT)"
        echo "HITBOX_CFG=$([ -f "$STATE/hitbox.cfg" ] && echo PRESENT || echo ABSENT)"
        echo "FPS_CAP=$(cat "$STATE/fps_cap" 2>/dev/null || echo not-set)"
        echo "ACTIVE_PROFILE=$(cat "$STATE/profile" 2>/dev/null || echo none)"
        echo "LAST_FAILURES=$(cat "$STATE/last_failures" 2>/dev/null || echo 0)"
        [ -r "$MODDIR/module.prop" ] && echo "MODULE_PROP=READABLE" || echo "MODULE_PROP=UNREADABLE"
        [ -w "$STATE" ] 2>/dev/null && echo "STATE_DIR=WRITABLE" || { mkdir -p "$STATE" 2>/dev/null && [ -w "$STATE" ] && echo "STATE_DIR=WRITABLE" || echo "STATE_DIR=READ_ONLY"; }
        echo "THERMAL_STATUS=$(dumpsys thermalservice 2>/dev/null | grep -m 1 -i 'Thermal Status' | sed 's/.*:[[:space:]]*//' | cut -c1-50)"
        echo "VERSION=30.2"
        ;;
      thermal)
        echo "THERMAL INTELLIGENCE — READ ONLY"
        for f in /sys/class/thermal/thermal_zone*/type; do
          [ -r "$f" ] || continue
          z=${f%/type}; t=$(cat "$z/temp" 2>/dev/null); typ=$(cat "$f" 2>/dev/null)
          [ -n "$t" ] && echo "ZONE_${typ}=$t"
        done | head -n 16
        echo "SAFETY=Android thermal throttling active"
        ;;
      memory)
        echo "MEMORY PRESSURE ANALYZER — READ ONLY"
        awk '/MemTotal:|MemAvailable:|SwapTotal:|SwapFree:|Cached:|Dirty:/{print}' /proc/meminfo 2>/dev/null
        [ -r /proc/pressure/memory ] && { echo "MEMORY_PSI:"; cat /proc/pressure/memory; } || echo "MEMORY_PSI=UNAVAILABLE"
        ;;
      graphics)
        echo "GRAPHICS CAPABILITY SCAN — READ ONLY"
        echo "GPU_VENDOR=$(getprop ro.hardware.egl)"
        echo "GPU_RENDERER=$(getprop ro.hardware.vulkan)"
        echo "OPENGLES_VERSION=$(getprop ro.opengles.version)"
        for f in /sys/class/kgsl/kgsl-3d0/gpu_model /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/devfreq/*gpu*/cur_freq /sys/class/devfreq/*mali*/cur_freq; do
          [ -r "$f" ] && echo "$(basename "$f")=$(cat "$f" 2>/dev/null)"
        done
        ;;
      appinfo)
        pkg="$3"; [ -n "$pkg" ] && valid_pkg "$pkg" || { echo "Select a supported game first."; exit 2; }
        echo "GAME PACKAGE INSPECTOR — READ ONLY"; echo "PACKAGE=$pkg"
        if pm path "$pkg" >/dev/null 2>&1; then
          echo "INSTALLED=YES"; echo "RESOLVED_PACKAGE=$pkg"
          pm path "$pkg"
          dumpsys package "$pkg" 2>/dev/null | grep -m 1 -E 'versionName=|versionCode='
        else echo "INSTALLED=NO"; exit 1; fi
        ;;
      power)
        echo "POWER & BATTERY PROFILE — READ ONLY"
        for f in capacity status health temp voltage_now current_now cycle_count charge_counter; do
          v=$(cat "/sys/class/power_supply/battery/$f" 2>/dev/null); [ -n "$v" ] && echo "$f=$v"
        done
        ;;
      *) echo "Usage: $0 engine {network|storage|battery|display|diagnostics|frames|thermal|memory|graphics|appinfo|power}"; exit 2 ;;
    esac
    ;;

  config)
    mkdir -p "$STATE" || exit 1
    case "$2" in
      save)
        mode="$3"; game="$4"; pkg="$5"; fps="$6"; refresh="$7"; animation="$8"
        features="${9}"
        case "$mode" in saver|balanced|gaming) ;; *) echo "Invalid profile mode."; exit 2 ;; esac
        [ -z "$pkg" ] || valid_pkg "$pkg" || { echo "Invalid package."; exit 2; }
        valid_fps "$fps" || { echo "Invalid FPS target ($fps)."; exit 2; }
        case "$refresh" in ''|60|90|120|144|165) ;; *) echo "Invalid refresh target."; exit 2 ;; esac
        case "$animation" in ''|0|0.4|0.5|0.6|1|1.5|2|5|10) ;; *) echo "Invalid animation scale."; exit 2 ;; esac
        tmp="$STATE/ui_config.tmp"
        printf '%s|%s|%s|%s|%s|%s|%s\n' "$mode" "$game" "$pkg" "$fps" "$refresh" "$animation" "$features" > "$tmp" || exit 1
        mv "$tmp" "$STATE/ui_config" || exit 1
        echo "PROFILE_SAVED=YES"
        echo "GAME=$game"
        echo "PACKAGE=${pkg:-unmapped}"
        echo "FPS_TARGET=$fps"
        echo "FEATURES=${features}"
        echo "SAVE_LOCATION=plugin state/ui_config"
        log "config saved mode=$mode game=$game pkg=$pkg fps=$fps features=$features"
        autosave_state
        ;;
      load)
        if [ -r "$STATE/ui_config" ]; then
          printf 'CONFIG='; cat "$STATE/ui_config"
        else
          echo "CONFIG=gaming|Mobile Legends|com.mobile.legends|144|90|1|game_mode,refresh,animation,telemetry,frames,network,battery,storage,thermal,hitbox,aim"
        fi
        ;;
      *) echo "Usage: $0 config {save|load} ..."; exit 2 ;;
    esac
    ;;

  restore) exec sh "$MODDIR/optimize.sh" restore ;;
  logs) tail -n 200 "$LOGDIR/engine.log" 2>/dev/null || echo "No engine log yet." ;;

  *)
    echo "ZTC BOOSTER v30.2 ZTC X ULTRA — Head-Priority Aim Engine v3"
    echo "Usage: $0 {apply|status|telemetry|health|capabilities|engine <sub>|compile|restore|logs|aim <sub>|hitbox <sub>|framepace <sub>|config <sub>}"
    echo "FPS targets: 30 45 60 90 120 144 165 240 440 1000 uncapped"
    echo "Aim presets: ztc_head_max ztc_sharp cod_mobile pubg free_fire generic_shooter"
    echo "Hitbox presets: max advanced balanced"
    exit 2
    ;;
esac
