#!/system/bin/sh
# ZTC BOOSTER v30.2 — AxManager-compatible installer hook.
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSSERVICE=true

zyn_print() {
  if command -v ui_print >/dev/null 2>&1; then ui_print "$1"; else echo "$1"; fi
}

if [ -z "${MODPATH:-}" ] || [ ! -d "$MODPATH" ]; then
  if command -v abort >/dev/null 2>&1; then abort "ZTC BOOSTER: installer did not provide MODPATH."; fi
else
  if [ ! -f "$MODPATH/module.prop" ]; then
    if command -v abort >/dev/null 2>&1; then abort "ZTC BOOSTER: module.prop missing after extraction."; fi
  fi
  chmod 0755 "$MODPATH" "$MODPATH/service.sh" "$MODPATH/action.sh" "$MODPATH/optimize.sh" "$MODPATH/uninstall.sh" 2>/dev/null
  chmod 0755 "$MODPATH/webroot" 2>/dev/null
  chmod 0644 "$MODPATH/module.prop" "$MODPATH/webroot/index.html" "$MODPATH/webroot/main.js" 2>/dev/null
  if [ "${AXERON:-false}" = "true" ]; then
    zyn_print "ZTC BOOSTER v30.2 — AxManager plugin"
    zyn_print "AxManager server: ${AXERONVER:-unknown}"
    zyn_print "Plugin ID: zyn_booster"
    zyn_print "WebUI: webroot/index.html"
    zyn_print "Aim Engine: v3 — head-priority, max sticky, instant snap"
    zyn_print "Hitbox Engine: v2 — HEAD_MULTIPLIER 1.65, real Android injection"
    zyn_print "Auto-save: all features persist to state/ instantly"
    zyn_print "Boot re-apply: active profile + hitbox restored on every boot"
  fi
fi

print_modname() {
  ui_print "  ZTC BOOSTER v30.2 TITAN X ULTRA"
  ui_print "  Head-Priority Aim Engine v3 + Max Hitbox v2"
}
on_install() {
  ui_print "- Verifying Android device and available interfaces..."
  ui_print "- Aim Engine v3: HEADSHOT_BIAS=0.88, HEAD_SNAP_BIAS=0.95, PREDICT_MS=28"
  ui_print "- Hitbox v2: HEAD_MULTIPLIER=1.65, TOUCH_SLOP=16, DISPATCH=10ms"
  ui_print "- Auto-save active: all settings written instantly to state/"
  ui_print "- Boot re-apply: profile + hitbox restored on every reboot"
  ui_print "- Thermal safeguards remain enabled."
}
set_permissions() {
  set_perm_recursive "$MODPATH" 0 0 0755 0644
  set_perm "$MODPATH/service.sh"   0 0 0755
  set_perm "$MODPATH/action.sh"    0 0 0755
  set_perm "$MODPATH/optimize.sh"  0 0 0755
  set_perm "$MODPATH/uninstall.sh" 0 0 0755
}
