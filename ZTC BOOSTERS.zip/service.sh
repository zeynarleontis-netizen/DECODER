#!/system/bin/sh
# ZTC BOOSTER v30.2 — service.sh
# Boot re-apply: runs at LATESTART, waits for boot, re-applies active_profile
# Auto-save: any config written during session is live-persisted to state/
# Instantly runs in background after module is loaded

MODDIR="${0%/*}"
STATE="$MODDIR/state"
LOGDIR="$MODDIR/logs"
mkdir -p "$STATE" "$LOGDIR"
chmod 0755 "$MODDIR" "$STATE" "$LOGDIR" 2>/dev/null
LOG="$LOGDIR/engine.log"

log() { printf '%s | %s\n' "$(date '+%Y-%m-%d %H:%M:%S' 2>/dev/null)" "$*" >> "$LOG"; }

log "ZTC BOOSTER v30.2 service started"
[ "${AXERON:-false}" = "true" ] && manager="AxManager" || manager="Magisk/KernelSU"
log "Manager: $manager"
log "Device: $(getprop ro.product.manufacturer) $(getprop ro.product.model)"
log "Android: $(getprop ro.build.version.release) / SDK $(getprop ro.build.version.sdk)"

# ── Wait for boot complete (max 120s) ────────────────────────────────────────
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 60 ]; do
  sleep 2; i=$((i + 1))
done

valid_fps_full() {
  case "$1" in 30|45|60|90|120|144|165|240|440|1000|uncapped) return 0 ;; *) return 1 ;; esac
}

if [ "$(getprop sys.boot_completed)" = "1" ]; then
  printf 'ready\n' > "$STATE/status"
  log "Boot complete"

  # ── Re-apply hitbox settings (auto-save ensures they survive reboot) ───────
  if [ -f "$STATE/hitbox.cfg" ]; then
    log "Re-applying hitbox from state/hitbox.cfg"
    slop="$(grep '^TOUCH_SLOP_OVERRIDE=' "$STATE/hitbox.cfg" 2>/dev/null | cut -d= -f2)"
    [ -n "$slop" ] && settings put secure touch_slop_override "$slop" >/dev/null 2>&1 && log "touch_slop=$slop"
    settings put system pointer_speed 8 >/dev/null 2>&1 && log "pointer_speed=8"
    settings put secure long_press_timeout 160 >/dev/null 2>&1 && log "long_press_timeout=160"
  fi

  # ── Re-apply main profile ──────────────────────────────────────────────────
  if [ -r "$STATE/active_profile" ]; then
    IFS='|' read -r profile pkg refresh animation fps_target features < "$STATE/active_profile"
    case "$profile" in saver|balanced|gaming)
      case "$pkg" in *[!A-Za-z0-9_.]*)  pkg=""  ;; .*|*.) pkg="" ;; esac
      case "$refresh" in ''|60|90|120|144|165) ;; *) refresh="" ;; esac
      case "$animation" in ''|*[!0-9.]*|.*|*.) animation="" ;; esac
      valid_fps_full "$fps_target" || fps_target="60"
      log "Re-applying: profile=$profile pkg=$pkg refresh=$refresh animation=$animation fps=$fps_target"
      sh "$MODDIR/optimize.sh" "$profile" "$pkg" "$refresh" "$animation" "$fps_target" "$features" >> "$LOGDIR/engine.log" 2>&1
      log "Boot re-apply exit=$?"
      ;;
      *) log "Saved profile invalid; skipped" ;;
    esac
  else
    log "No saved profile; Android settings unchanged"
  fi

  log "Service ready — all auto-save hooks active"
else
  printf 'boot_timeout\n' > "$STATE/status"
  log "Boot wait timed out after 120s"
fi

exit 0
